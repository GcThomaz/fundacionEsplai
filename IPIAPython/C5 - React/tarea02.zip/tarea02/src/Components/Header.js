import '../Styles/header.css';

function Header() {
  return (
      <div id="header-box">
        <h1>Encabezado de la Aplicacion</h1>
      </div>
  );
}

export default Header;