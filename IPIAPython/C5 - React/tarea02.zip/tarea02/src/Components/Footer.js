
import '../Styles/footer.css';

function Footer() {
  return (
    <footer>
      <div id="footer-box">Pie de Pagina de Aplicacion</div>
    </footer>
  );
}

export default Footer;