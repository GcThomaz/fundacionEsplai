import '../Styles/buton.css';

function Buton() {
  return (

      <div>
      <button id="button"><strong>Read this</strong></button>
      </div>
  );
}

export default Buton;